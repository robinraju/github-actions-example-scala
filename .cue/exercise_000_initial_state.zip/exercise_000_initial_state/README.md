## Play Framework - Introduction

Play is a high-productivity Java and Scala web application framework that integrates 
the components and APIs you need for modern web application development.
